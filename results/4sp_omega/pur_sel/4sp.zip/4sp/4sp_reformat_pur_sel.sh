tail -n +2 4_sp_annotation_fdr/branch.BGM.dNdS.summary > tmp.tab

echo -e "OG BGM_model BGM_dNdS BGM_t BGM_dN BGM_dS BAT_model BAT_dNdS BAT_t BAT_dN BAT_dS BRO_model BRO_dNdS BRO_t BRO_dN BRO_dS" > 4sp_pur_sel.tab

while read line;

do

	og=$(echo $line | awk '{print $2}' | awk -F "." '{print $1}');

	BGM_line=$(echo $line | awk '{print $3" "$4" "$5 " "$6" "$7}')

	BAT_line=$(grep $og 4_sp_annotation_fdr/branch.BAT.dNdS.summary | awk '{print $3" "$4" "$5 " "$6" "$7}');

	BRO_line=$(grep $og 4_sp_annotation_fdr/branch.BRO.dNdS.summary | awk '{print $3" "$4" "$5 " "$6" "$7}');

	echo $og $BGM_line $BAT_line $BRO_line  >> 4sp_pur_sel.tab;

done <  tmp.tab

rm tmp.tab
