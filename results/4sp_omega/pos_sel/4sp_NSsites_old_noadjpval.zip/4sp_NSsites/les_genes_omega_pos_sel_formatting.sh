echo "OG BAT_bs_omega_model BAT_bs_omega_sites BRO_bs_omega_model BRO_bs_omega_sites BGM_bs_omega_model BGM_bs_omega_sites" > omega_bs.tab

for i in BAT_bs_analyze/*out;

do

#	unset $og $BAT_model $BAT_sites $BRO_model $BRO_sites $BGM_model $BGM_sites

	og=$(echo $i | awk -F "/" '{print $2}' | awk -F "." '{print $1}');

        if [[  -f "BAT_bs_analyze/$og.ref.mafft.n_replicate_1_model_alternative.out" ]] || [[  -f "BAT_bs_analyze/$og.ref.mafft.n_replicate_1_model_general.out" ]];
        then
	BAT_model=$(echo $i | awk -F "_" '{print $NF}' | awk -F "." '{print $1}' );
	BAT_sites=$(grep -c "*" $i | awk '{print $1 -2}');
	else
    	BAT_model=NA;
        BAT_sites=NA;
        fi;


	if [[  -f "BRO_bs_analyze/$og.ref.mafft.n_replicate_1_model_alternative.out" ]] || [[  -f "BRO_bs_analyze/$og.ref.mafft.n_replicate_1_model_general.out" ]];
        then
	BRO_model=$(echo BRO_bs_analyze/$og*.out | awk -F "_" '{print $NF}' | awk -F "." '{print $1}' );
	BRO_sites=$(grep -c "*" BRO_bs_analyze/$og*.out | awk '{print $1 -2}');
	else
	BRO_model=NA;
        BRO_sites=NA;
        fi;


	if [[  -f "BGM_bs_analyze/$og.ref.mafft.n_replicate_1_model_alternative.out" ]] || [[  -f "BGM_bs_analyze/$og.ref.mafft.n_replicate_1_model_general.out" ]];
	then
	BGM_model=$(echo BGM_bs_analyze/$og*.out | awk -F "_" '{print $NF}' | awk -F "." '{print $1}' );
	BGM_sites=$(grep -c "*" BGM_bs_analyze/$og*.out | awk '{print $1 -2}');
	else
	BGM_model=NA;
	BGM_sites=NA;
	fi;

	echo "$og $BAT_model $BAT_sites $BRO_model $BRO_sites $BGM_model $BGM_sites" >> omega_bs.tab;

done
